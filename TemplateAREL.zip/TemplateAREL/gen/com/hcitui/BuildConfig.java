/** Automatically generated file. DO NOT MODIFY */
package com.hcitui;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}